let amor = prompt("Quanto você me ama hoje?");

if (amor < 80) {
 alert("Não gostei, tá chatinha em, Eu amo mais:[");
} else if (amor >= 80 && amor <= 95) {
  alert("Gostei, mas ainda pode ser melhor. Eu amo mais:)");
} else if (amor > 95) {
  alert("Ótimo! Mas eu ainda amo mais meu beem:3");
}




